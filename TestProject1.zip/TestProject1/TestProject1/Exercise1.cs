using StudentServiceLib;

namespace TestProject1
{
    [TestClass]
    public class TestScore
    {
        [TestMethod]
        public void ScoreIs8ReturnA()
        {
            Student s = new Student();
            s.Score = 8;

            char letter = s.getLetterScore();
            Assert.AreEqual('A', letter);
        }


        [TestMethod]
        public void ScoreIs7ReturnB()
        {
            Student s = new Student();
            s.Score = 7;

            char letter = s.getLetterScore();
            Assert.AreEqual('B', letter);
        }

        [TestMethod]
        public void ScoreIs5ReturnC()
        {
            Student s = new Student();
            s.Score = 5;

            char letter = s.getLetterScore();
            Assert.AreEqual('C', letter);
        }

        [TestMethod]
        public void ScoreIs35ReturnD()
        {
            Student s = new Student();
            s.Score = 3.5;

            char letter = s.getLetterScore();
            Assert.AreEqual('D', letter);
        }

        [TestMethod]
        public void ScoreisLower35ReturnE()
        {
            Student s = new Student();
            s.Score = 2;

            char letter = s.getLetterScore();
            Assert.AreEqual('E', letter);
        }

        [TestMethod]
        public void ScoreIsHigherThan10_Throw_SystemExeption()
        {
            Student s = new Student();
            bool exeptionOccured = false;
            try
            {
                s.Score = 11;
            }
            catch
            {
                exeptionOccured = true;
            }
            Assert.IsTrue(exeptionOccured);
        }




    }




}